# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 14:36:23 2019

@author: Administrator
项目9：中国姓氏研究
"""
import pandas as pd
import warnings
warnings.filterwarnings("ignore")
import os
os.chdir(r"F:\pythondata\Python微专业\【非常重要】课程资料\python_minor_project\项目7_15\项目09中国姓氏排行研究")
for i in ["./img","./data","./html"]:
    if not os.path.exists(i):
        os.mkdir(i)

##################################################################################
############################ 1、数据清洗、整合 ####################################
##################################################################################
print("               《项目9: 中国姓氏排行研究》\n")
print(">>>>>>>>>>>>>>>>> 任务1. 数据清洗、整合 <<<<<<<<<<<<<<<<<<<\n")
filename="./data/data_new.csv"
if os.path.exists(filename):
    data_new=pd.read_csv(filename,engine="python",encoding="utf-8")
    print(">> 读取清洗后的本地数据 ———— %s,数据量为: %d行"%(filename.replace("./data/","").strip(".csv"),data_new.shape[0]))
else:
    # 读取数据 data01 data02
    data01=pd.read_csv("data01.csv",engine="python",encoding="utf-8")
    data02=pd.read_csv("data02.csv",engine="python",encoding="utf-8")
    data=pd.concat([data01,data02],axis=0)
    # 读取行政区数据
    province=pd.read_excel("中国行政代码对照表.xlsx").drop_duplicates()
    # 省份列表后续备用
    province_list=[i for i in province["省"].unique() if "省" in i]   # 省份
    city_list=[i+"市" if "市" not in i else i for i in province["市"].unique() if i not in set(province_list)]  # 市
    region_list=[i for i in province["区/县"].unique() if i not in set(province_list)|set(city_list)]   # 区县
    # 全部正确地址信息,用在后续决定是否进行字符匹配。   
    #all_list=set(province_list)|set(i.strip("市") for i in city_list)|set(region_list)
    # 更改province中行政编码和data中的行政编码
    province["行政编码"]=province["行政编码"].astype(str)
    data["户籍地城市编号"]=data["户籍地城市编号"].astype(str)
    data["户籍地城市编号"]=data["户籍地城市编号"].str.replace("\.0","")
    # 连接经纬度
    data_new=pd.merge(data,province,left_on="户籍地城市编号",right_on="行政编码")
    print("数据共计%d行"%data_new.shape[0])
    # 修改字段
    data_new.drop(['户籍地城市编号', '行政编码'],axis=1,inplace=True)
    # 只修改除姓和工作地之外的字段
    data_new.columns=["户籍所在地_"+j if i>=2 else j for i,j in enumerate(data_new.columns)]
    print(">> 数据连接完成.")
    #####################################  提取地址信息 ##################################
    # 特殊处理的省市区 四个直辖市、自治区、特别行政区,以及青瓷出那些缺省”省“字的字符
    ## STEP1： 通过匹配已有的数据
    special_province={"省":province_list,
                      "普通市":city_list,
                      "直辖市":["上海","北京","天津","重庆"],
                      "自治区":["广西壮族","宁夏回族","新疆维吾尔","内蒙古","西藏"],
                      "特别行政区":["香港","澳门"],
                      "区县":region_list}
    # 清除多余的数据
    del data;del data01;del data02;del province
    #print(">> 多余数据清除完成.")
    # 去除标点符号
    import re
    clean_pattern=re.compile(r"[\u4e00-\u9fa5\w]+")
    
    # 正则匹配
    def reg_match(s,pattern=clean_pattern):
        """通过相应的正则表达式提取对应的省市区信息.
        s: 原始文本信息
        pattern: 提取信息的正则表达式
        """
        if isinstance(pattern,list):  # 如果传入的是一个列表则取最先匹配到的
            result=[i.findall(str(s))[0] for i in pattern if len(i.findall(str(s)))!=0]
        else:
            result=pattern.findall(str(s))
        if len(result)!=0:
            return result[0]
        else:
            return "未识别"
    # 清洗多余的标点符号
    data_new["工作地"]=data_new["工作地"].map(reg_match)
    print(">> 标点符号清洗完成.")
    data_new=data_new.drop_duplicates().reset_index(drop=True)
    ##################################### 原始地点信息本身就有错误，需要预处理 ##############################
    import time
    print(">> Step 0.1: 工作地数据预处理开始,此步骤较为耗时,请耐心等候...")
    time0=time.time()
    need_replace=dict(zip([i.replace("省","市") for i in province_list],province_list))  # 防止有些记录错误的把省份写成市
    need_replace.update({"河市省":"河南省","湖市省":"湖南省","云市省":"云南省",
                  "广州省":"广东省","广西省":"广西壮族自治区","广西市":"广西壮族自治区",
                  "安微省":"安徽省","新疆省":"新疆维吾尔自治区","内蒙古省":"内蒙古自治区",
                  "新疆市":"新疆维吾尔自治区","内蒙古市":"内蒙古自治区","淅江省":"浙江省",
                  "市京市":"南京市","赣县昌市":"南昌市"})
    for i in need_replace.keys():
        data_new["工作地"]=data_new["工作地"].str.replace(i,need_replace[i])
    time2=time.time()
    print(">> Step 0.2: 预处理完成,已将错写为市的省份修改完成. 耗时: %.2fs"%(time2-time0))
    # 分别提取省市区信息
    try:
        data_new.drop(["工作地_省","工作地_市","工作地_区/县"],axis=1,inplace=True)
    except:
        pass#print(">> 不需要删除.")  # 此句无实际作用，调试过程中需要重新设置字段，需要初始化

    # 字符匹配
    def str_match(origin_position,special_province,position=None):
        """地点进行信息匹配，将直辖市、自治区、特别行政区的信息进行提取.
        origin_position：原始工作地
        special_province: 特殊地点字典
        position:地址维度，默认为None返回结果为省，当指定时返回特定的城市或者区县
        """
        def get_new_pro(origin_position,special_province,key):
            """返回匹配到的地址."""
            new_pro="未识别"
            # 后缀：省、市
            suffix={"直辖市":"市","区县":"","自治区":"自治区","特别行政区":"","省":"省","普通市":""}
            for j in special_province[key]:
                if j in origin_position:
                    new_pro=j+suffix[key]
                    break
            return new_pro
        # 匹配城市或区县
        if position and any(j in origin_position for j in special_province[position]):
            return get_new_pro(origin_position,special_province,position)
        # 省份
        elif position==None and any(origin_position.find(j)==0 for j in special_province["省"]):
            return get_new_pro(origin_position,special_province,"省")
        # 直辖市
        elif position==None and any(origin_position.find(j)==0 for j in special_province["直辖市"]):
            return get_new_pro(origin_position,special_province,"直辖市")
        # 自治区
        elif position==None and any(origin_position.find(j)==0 for j in special_province["自治区"]):
            return get_new_pro(origin_position,special_province,"自治区")
        # 特别行政区
        elif position==None and any(origin_position.find(j)==0 for j in special_province["特别行政区"]):
            return get_new_pro(origin_position,special_province,"特别行政区")
        else:
            return "未识别"
    """
    小记：关于先使用正则匹配还是字符匹配的顺序问题，先后做了多次尝试，后发现如果一开始就使用字符匹配，需要对
    全部地址多次进行字典内的循环遍历，极大降低程序数据清洗的效率，之后考虑了一下方法在保证尽量高的准确度的情
    况下提高清洗速度：
    1、首先进行正则匹配，即按照一定的规律去匹配省、市、地区，这样得到的清洗结果会有三种情况：
        i.未识别;
        ii.正确的地址;
        iii.错误的地址，一般是字符数提取过多。
    2、针对1的遗留情况，再次使用字符匹配，对除 ii 以外的数据再次进行字符匹配，大大减少了记录数。
    """
    ## STEP1 正则匹配
    import re
    # 省
    pro_pattern=re.compile(r".+?省")
    # 市
    city_pattern=[re.compile(r"省(.+?市)"),re.compile(r"自治区(.+?市)"),re.compile(r".+?市")]
    # 区 / 县
    region_pattern=[re.compile(r"市(.+?区)"),re.compile(r"市(.+?县)"),
                    re.compile(r"省(.+?区)"),re.compile(r"省(.+?县)"),
                    re.compile(r"自治区(.+?区)"),re.compile(r"自治区(.+?县)"),
                    re.compile(r"(.+?区)"),re.compile(r"(.+?县)")]
    # Step1 ：正则匹配
    print(">> Step 1.1: 工作地的省市区县信息(正则匹配)开始，请稍等...")
    time1=time.time()
    data_new["工作地_省"]=pd.Series(map(lambda x:reg_match(x,pro_pattern),data_new["工作地"]))
    data_new["工作地_市"]=pd.Series(map(lambda x:reg_match(x,city_pattern),data_new["工作地"]))
    # 首先是区
    data_new["工作地_区/县"]=pd.Series(map(lambda x:reg_match(x,region_pattern),data_new["工作地"]))
    time2=time.time()
    print(">> Step 1.2: 工作地的省市区县信息(正则匹配)完成. 耗时: %.2fs"%(time2-time1))
    
    # Step2 字符匹配
    print(">> Step 2.1: 工作地的省市区县信息(字符匹配)开始...")
    time1=time.time()
    data_new["工作地_省"]=pd.Series(map(lambda x,y:str_match(x,special_province) if y=="未识别" else y,data_new["工作地"],data_new["工作地_省"]))
#    data_new["工作地_市"]=pd.Series(map(lambda x,y:str_match(x,special_province,"普通市") if y=="未识别" else y,data_new["工作地"],data_new["工作地_市"]))
#    data_new["工作地_区/县"]=pd.Series(map(lambda x,y:str_match(x,special_province,"区县") if y=="未识别" else y,data_new["工作地"],data_new["工作地_区/县"]))
    time2=time.time()
    print(">> Step 2.2: 工作地的省市区县信息(字符匹配)完成. 耗时: %.2fs"%(time2-time1))
    
    ###############################  手动修正一些错误数据 #########################
    temp=data_new["工作地_省"].value_counts()  # 查看数据的频次
    need_replace={"江省":"浙江省","苏省":"江苏省","西安市碑林区长安路15段五号省":"陕西省"}
    for i in need_replace.keys():
        data_new["工作地_省"]=data_new["工作地_省"].map(lambda x:x if x!=i else need_replace[i]) # 替换错误值
    # 再次检查，修正后出现频次降序排名34位以后的全部标记为 "未识别"。 即23个省+4个直辖市+4个自治区+2个特别行政区（共33个）
    all_pro=set(province_list)|set(["未标记","香港","澳门","广西壮族自治区","宁夏回族自治区","新疆维吾尔自治区",
    "内蒙古自治区","西藏自治区","上海市","北京市","天津市","重庆市"])
    data_new["工作地_省"]=data_new["工作地_省"].map(lambda x:x if x in all_pro else "未识别") # 替换错误值
    # 重新查看省份的频次
    temp=data_new["工作地_省"].value_counts()  # 查看数据的频次
    print(">> Step 3.1: 工作地_省错误信息替换完成.")

    # 清洗那些市的名称中混入省的字符，进行剔除
    def remove_pro(province,city,region=False):
        """有些城市名称会混入省份，比如河南郑州市，这个时候就需要进行清洗.
        特别注明：吉林省吉林市属特殊情况，如本函数正常逻辑去处理则会得到空白字符
        province:省份
        city:城市
        """
        province,city=str(province),str(city)
        if "吉林" in city:   # 特殊处理
            return "吉林"
        elif city=="津市":
            return "津市"
        elif city=="哈":
            return "哈尔滨"
        elif province=="未识别" or city=="未识别":
            return "未识别"
        # 因为混入的省名不带 “省”，所以需要进行替换
        elif "自治区" in province:
        # 自治区替换
            for i in ["广西","宁夏","壮族","回族","新疆","维吾尔","内蒙古","西藏","自治区"]:
                city=city.replace(i,"")
            return city.strip("市")
        elif "省" in province:
            province=province.strip("省")
            city=city.replace(province,"").strip("市省")
            return city
        elif region:  # 如果是地区，则城市里的地名是可以删除的
            province=province.strip("市省")
            city=city.replace(province,"").strip("市省")
            return city
        else:
            return city.strip("市省")
    # 清洗城市字段
    data_new["工作地_市"]=pd.Series(map(lambda x,y:remove_pro(x,y),data_new["工作地_省"],data_new["工作地_市"]))
    data_new["工作地_市"]=data_new["工作地_市"].map(lambda x:x if len(x)<=5 else "未识别")
    #temp=data_new["工作地_市"].value_counts()
#    data_new["工作地_区/县"]=pd.Series(map(lambda x,y:remove_pro(x,y,True),data_new["工作地_省"],data_new["工作地_区/县"]))
#    data_new["工作地_区/县"]=pd.Series(map(lambda x,y:remove_pro(x,y,True),data_new["工作地_市"],data_new["工作地_区/县"]))
    print(">> Step 3.2: 工作地_市中包含的省份以及工作地_区/县中包含的省市剔除完成.")
    data_new=data_new[(data_new["工作地_省"]!="未识别")|(data_new["工作地_市"]!="未识别")]
    # 去除经纬度为-1的记录
    data_new=data_new[(data_new["户籍所在地_lat"]!=-1)&(data_new["户籍所在地_lng"]!=-1)].reset_index(drop=True)                  
    time2=time.time()
    print(">> finished! 工作地数据全部清洗完成.最后数据量为: %d行,总耗时: %.2fs"%(data_new.shape[0],time2-time0))
    # 保存清洗后的结果
    data_new.to_csv(filename,index=False,encoding="utf-8")
    print(">> 清洗后的数据导出完成.")
    
##################################################################################
############################ 2、查看姓氏普遍指数 ##################################
##################################################################################
print("\n>>>>>>>>>>>>>>>>>> 任务2. 姓氏普遍指数 <<<<<<<<<<<<<<<<<<<<\n")
# (1) 姓氏Top20
filename="./data/中国姓氏排名.csv"
if os.path.exists(filename):
    name=pd.read_csv(filename,engine="python",encoding="utf-8")
    print(">> 读取清洗后的本地数据 ———— %s,数据量为: %d行"%(filename.strip("./data/").strip(".csv"),name.shape[0]))
else:
    name=pd.DataFrame(data_new["姓"].value_counts()).reset_index().rename(columns={"姓":"num","index":"lastname"})
    name["percent"]=name["num"]/name["num"].sum()
    name.to_csv(filename,index=False,encoding="utf-8")
##################################### 可视化 #####################################
from bokeh.plotting import figure,show,output_file

output_file("./html/中国姓氏Top20.html")
# 绘制散点图
# 十字标签
from bokeh.models import ColumnDataSource
from bokeh.models import HoverTool

df = name[:20]   # 只取Top20

df.index.name = 'index'
source = ColumnDataSource(df)

hover = HoverTool(tooltips=[
                            ("姓氏", "@lastname"),
                            ("数量", "@num"),
                            ("占比","@percent")
                        ])


# 柱状图

def plot_bar(source,col,color,title):
    """柱状图"""
    TOOLS = [hover,"xpan,box_zoom,save,reset,crosshair"]
    p = figure(x_range=source.data["lastname"].tolist(),plot_width=800,plot_height=300, title=title,tools=TOOLS)
    
    p.vbar(x='lastname', top=col, source=source,    # 加载数据另一个方式
           width=0.9, alpha = 0.8,
           color = color,#factor_cmap('fruits', palette=Spectral6, factors=fruits),    # 设置颜色
           )
    
    p.xgrid.grid_line_color = None
    p.legend.orientation = "horizontal"
    # 其他参数设置
    
    return p

# 口味得分
s1=plot_bar(source,"num","red","中国姓氏Top20: 数量")
# 性价比得分
s2=plot_bar(source,"percent","green","中国姓氏Top20: 占比")

# 如何拼接起来
from bokeh.layouts import gridplot

p = gridplot([[s1],[s2]])
show(p)

# (2) 王姓和姬姓的全国分布
def name_distribute(lastname,data):
    '''筛选data中姓氏为lastname的全部数据.'''
    result=data[data["姓"]==lastname][["姓","户籍所在地_lng","户籍所在地_lat"]].groupby(by=["户籍所在地_lng",
    "户籍所在地_lat"]).count().reset_index().rename(columns={"姓":lastname})
    return result
# 防止修改已有的文件
for i,j in [("./data/王姓全国热力图.xlsx","王"),("./data/姬姓全国热力图.xlsx","姬")]:
    if os.path.exists(i):
        print(">>",i.strip("./data/").strip(".xlsx"),"数据已存在,无需计算.")
        continue
    else:
        # 王姓
        result=name_distribute(j,data_new)
        result.to_excel(i,index=False,sheet_name=j)
        

##################################################################################
############################### 3、奔波指数 ######################################
##################################################################################
print("\n>>>>>>>>>>>>>>>>>>>  任务3. 奔波指数 <<<<<<<<<<<<<<<<<<<<<<\n")
filename="./data/home_to_work.xlsx"
if os.path.exists(filename):
    home_to_work=pd.read_excel(filename,encoding="utf-8")
    print(">> 读取清洗后的本地数据 ———— %s,数据量为: %d行"%(filename.replace("./data/","").strip(".csv"),home_to_work.shape[0]))
else:
    # 去除"未识别"的工作地
    data_new_r=data_new[(data_new["工作地_省"]!="未识别")&(data_new["工作地_市"]!="未识别")&(data_new["工作地_区/县"]!="未识别")]
    # 去除 工作地==户籍所在地的人的数据.
    data_new_r["工作地_标准"]=data_new_r["工作地_省"]+data_new_r["工作地_市"]+data_new_r["工作地_区/县"]
    data_new_r["户籍地_标准"]=data_new_r["户籍所在地_省"]+data_new_r["户籍所在地_市"]+data_new_r["户籍所在地_区/县"]
    data_new_r=data_new_r[data_new_r["工作地_标准"]!=data_new_r["户籍地_标准"]][["姓","户籍所在地_lng",
    "户籍所在地_lat","工作地_市","工作地_区/县"]]
    # 修改列名
    data_new_r.columns=["lastname","home_lng","home_lat","workplace_city","workplace_region"]
    
    print("筛选前数据量为: %d行，筛选后数据量为: %d行"%(data_new.shape[0],data_new_r.shape[0]))
    # 筛选我自己的姓氏 "江"
    def name_data(lastname,data):
        """筛选data中姓氏为lastname的全部数据,排除了户籍地与工作地相同的人."""
        # 排除工作地_标准==户籍所在地_标准的数据
        result=data[data["lastname"]==lastname]
        num1,num2=data.shape[0],result.shape[0]
        print("总数据 %d行, 姓氏为'%s'的共%d行,占比为%.2f%%"%(num1,lastname,num2,num2/num1*100))
        return result
    
    # 导出数据
    home_to_work=name_data("江",data_new_r)
    home_to_work.to_excel(filename,index=False,encoding="utf-8")
    

print("\n Finished! Python部分工作全部完成.")




