# -*- coding: utf-8 -*-
"""
Created on Sat Apr 13 13:01:56 2019

@author: HASEE
项目10房价影响因素挖掘
"""
import pandas as pd
import warnings
warnings.filterwarnings("ignore")
import os
os.chdir(r"F:\pythondata\Python微专业\【非常重要】课程资料\python_minor_project\项目7_15\项目10房价影响因素挖掘")
for i in ["./img","./data","./html"]:
    if not os.path.exists(i):
        os.mkdir(i)

##################################################################################
############################ 1、数据清洗、整合 ####################################
##################################################################################
print("               《项目10: 房价影响因素挖掘》\n")
print(">>>>>>>>>>>>>>>>> 任务1. 数据清洗、整合 <<<<<<<<<<<<<<<<<<<")
filename="./data/house_rent_sell.csv"
if os.path.exists(filename):
    house_rent_sell=pd.read_csv(filename,engine="python",encoding="utf-8")
    print(">> 读取清洗后的本地数据 ———— %s,数据量为: %d行"%(filename.replace("./data/","").strip(".csv"),house_rent_sell.shape[0]))
else:
    filename1,filename2="house_rent","house_sell"
    house_rent=pd.read_csv("%s.csv"%filename1,engine="python")
    house_rent_new=house_rent.dropna()  # 去除缺失值
    print(">> %s原始数据量为: %d行,去除缺失值后剩 %d行."%(filename1,house_rent.shape[0],house_rent_new.shape[0]))
    house_sell=pd.read_csv("%s.csv"%filename2,engine="python")
    house_sell_new=house_sell.dropna()  # 去除缺失值
    print(">> %s原始数据量为: %d行,去除缺失值后剩 %d行."%(filename2,house_sell.shape[0],house_sell_new.shape[0]))
    
    ######################## 按小区进行数据汇总
    # 平均租金
    house_rent_community=house_rent[["community","price","area"]].groupby(by="community").sum()
    house_rent_community["rent_area"]=house_rent_community["price"]/house_rent_community["area"]
    # 平均售价
    house_sell["total_sell"]=house_sell["area"]*house_sell["average_price"]
    house_sell_community=house_sell[["property_name","total_sell","area"]].groupby(by="property_name").sum()
    house_sell_community["sell_area"]=house_sell_community["total_sell"]/house_sell_community["area"]
    # 数据连接
    house_rent_sell=house_rent_community[["rent_area"]].join(house_sell_community[["sell_area"]])
    # 添加经纬度
    house_rent_sell=pd.merge(house_rent_sell,house_rent[["community","lng","lat"]].drop_duplicates(),how="left",
                             left_index=True,right_on="community")[["community","rent_area","sell_area","lng","lat"]]
    house_rent_sell.dropna(inplace=True)
    house_rent_sell.to_csv(filename,index=False,encoding="utf-8")
    print(">> 数据清洗完成,数据量为: %d行."%house_rent_sell.shape[0])
    
##################################################################################
################################ 2、房屋售租比 ####################################
##################################################################################
# 售租比
house_rent_sell["sell/rent"]=house_rent_sell["sell_area"]/house_rent_sell["rent_area"]
# 可视化
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style("darkgrid")
plt.rcParams['font.sans-serif'] = ['SimHei']  # 中文字体设置-黑体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题
sns.set(font='SimHei')  # 解决Seaborn中文显示问题
# 直方图
fig=plt.figure(figsize=(8,6))
sns.distplot(house_rent_sell["sell/rent"],bins = 80,hist = True,kde = False,
            norm_hist=False,rug = False,vertical = False,
            color = 'y',axlabel = '')
plt.title("房屋售租比-直方图")
plt.savefig("./img/房屋售租比_直方图.png",dpi=200)

# 箱型图
fig=plt.figure(figsize=(8,6))
sns.boxplot(x="sell/rent", data=house_rent_sell,
            linewidth = 2,   # 线宽
            #width = 0.8,     # 箱之间的间隔比例
            fliersize = 3,   # 异常点大小
            palette = 'hls', # 设置调色板
            whis = 1.5,      # 设置IQR 
            notch = True,    # 设置是否以中值做凹槽
           )
plt.ylabel("sell_rent")
plt.xlabel("")
plt.title("房屋售租比-箱型图")
plt.savefig("./img/房屋售租比_箱型图.png",dpi=200)

# 中位数
month=house_rent_sell["sell/rent"].mean()
print(">> 售租比的中位数是: %d 月,大约是: %d年."%(month,month/12))



















